# Example Markdown Resource

This is an example markdown resource for the MCP Python starter.

You can use this file to serve static markdown content via the MCP resource handler.
